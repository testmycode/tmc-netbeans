int returns_zero()
{
	return 0; // ADD IMPL
}