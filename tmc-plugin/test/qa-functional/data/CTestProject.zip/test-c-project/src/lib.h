#ifndef LIB_H
#define LIB_H

int returns_zero();

#endif