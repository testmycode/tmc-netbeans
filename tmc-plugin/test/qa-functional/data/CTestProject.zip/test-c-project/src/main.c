#include "lib.h"

int main()
{
	return returns_zero();
}