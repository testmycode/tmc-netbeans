
public class Main {
    public static int add(int x, int y) {
        return x + y; // ADD IMPL
    }
    
    public static int sub(int x, int y) {
        return x - y; // SUB IMPL
    }
}
